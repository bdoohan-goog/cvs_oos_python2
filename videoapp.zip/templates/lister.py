myList = [33,22,1897,11,0,99]

def sort_list(list_):
    sort_list_sorted = list_.sort()
    return(sort_list_sorted)

if __name__ == "__main__":
    myList = [33,22,1897,11,0,99]
    aa = sort_list(myList)
    print(aa)
    print(myList)hs